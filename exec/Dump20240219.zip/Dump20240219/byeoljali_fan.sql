-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: my-mysql.cdokwwuykz7h.ap-northeast-2.rds.amazonaws.com    Database: byeoljali
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `fan`
--

DROP TABLE IF EXISTS `fan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fan` (
  `fan_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime(6) DEFAULT NULL,
  `last_modified_date` datetime(6) DEFAULT NULL,
  `birth` varchar(20) DEFAULT NULL,
  `certification_image_url` varchar(255) DEFAULT NULL,
  `change_count` int NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `is_blacklist` bit(1) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `profile_image_url` varchar(255) DEFAULT NULL,
  `roles` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fan`
--

LOCK TABLES `fan` WRITE;
/*!40000 ALTER TABLE `fan` DISABLE KEYS */;
INSERT INTO `fan` VALUES (1,'2024-01-31 12:35:41.379369','2024-02-16 00:30:50.577551','0303','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/allback123%40gmail.com/certificate/certImage.jpg',-87,'allback123@gmail.com',_binary '','윤태우','우태','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/allback123%40gmail.com/profile/profileImage.jpg','ROLE_FAN'),(3,'2024-01-31 14:22:15.421336','2024-02-14 10:22:22.286632','0705','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/wmg999%40hanmail.net/certificate/certImage.jpg',3,'wmg999@hanmail.net',_binary '\0','우미경','미미무','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/wmg999%40hanmail.net/profile/profileImage.jpg','ROLE_FAN'),(5,'2024-01-31 14:50:25.224696','2024-02-14 21:00:41.898663','1010','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/allice1010%40naver.com/certificate/certImage.jpg',3,'allice1010@naver.com',_binary '\0','정라엘','랄랄','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/allice1010%40naver.com/profile/profileImage.jpg','ROLE_FAN'),(6,'2024-01-31 14:51:29.790598','2024-02-16 00:07:40.928673','1019','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/dalsu_k%40naver.com/certificate/certImage.jpg',0,'dalsu_k@naver.com',_binary '\0','별자리','달달','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/dalsu_k%40naver.com/profile/profileImage.jpg','ROLE_FAN'),(27,'2024-02-06 16:12:47.146982','2024-02-13 12:37:03.325359','0508','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/ice_98%40naver.com/certificate/certImage.jpg',1,'ice_98@naver.com',_binary '\0','윤태호','윤태호','http://k.kakaocdn.net/dn/bfnFYT/btspg1BFDkI/mwIKbfRM4kA2pHdKhXkk30/img_640x640.jpg','ROLE_FAN'),(28,'2024-02-06 16:37:51.749587','2024-02-06 16:37:51.749587',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'chjnw0204@gmail.com',_binary '\0',NULL,'최진우','http://k.kakaocdn.net/dn/bq8nGk/btsALbeHr96/KydNXswwmGusKVLyiC9gS1/img_640x640.jpg','ROLE_FAN'),(39,'2024-02-07 11:36:31.309457','2024-02-15 23:51:57.026852','0722','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/ww71er%40hanmail.net/certificate/certImage.jpg',-100,'ww71er@hanmail.net',_binary '\0','ddd','dddd','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/ww71er%40hanmail.net/profile/profileImage.jpg','ROLE_FAN'),(40,'2024-02-08 13:58:55.490044','2024-02-08 13:58:55.490044',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'iniyap@kakao.com',_binary '\0',NULL,'해인','http://k.kakaocdn.net/dn/AaD7S/btsEBq6l5Vg/LuOMLBjbzrekicVyovHHqk/img_640x640.jpg','ROLE_FAN'),(41,'2024-02-08 16:04:41.806146','2024-02-08 16:04:41.806146',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'jww5555@naver.com',_binary '\0',NULL,'위재원','http://k.kakaocdn.net/dn/dl8TWW/btsDwEkrwSK/fOP6q9cg5YpV6iAXhttAFk/img_640x640.jpg','ROLE_FAN'),(42,'2024-02-11 03:40:59.232213','2024-02-11 03:40:59.232213',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'cjddktkdwk@naver.com',_binary '\0',NULL,'성완','http://k.kakaocdn.net/dn/1G9kp/btsAot8liOn/8CWudi3uy07rvFNUkk3ER0/img_640x640.jpg','ROLE_FAN'),(43,'2024-02-12 23:40:45.102345','2024-02-12 23:41:13.749877',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'cuzzzu1318@naver.com',_binary '\0','null','g힝','http://k.kakaocdn.net/dn/1G9kp/btsAot8liOn/8CWudi3uy07rvFNUkk3ER0/img_640x640.jpg','ROLE_FAN'),(44,'2024-02-13 15:17:47.947121','2024-02-13 15:17:47.947121',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'duddms0190@naver.com',_binary '\0',NULL,'최영은','http://k.kakaocdn.net/dn/1G9kp/btsAot8liOn/8CWudi3uy07rvFNUkk3ER0/img_640x640.jpg','ROLE_FAN'),(45,'2024-02-13 19:19:03.376794','2024-02-13 19:19:03.376794',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'kcheong321@nate.com',_binary '\0',NULL,'김정민','http://k.kakaocdn.net/dn/9kJ8j/btrKuvOPzoC/lWkMGOeQRZC9MUqCkOJcl1/img_640x640.jpg','ROLE_FAN'),(46,'2024-02-14 01:11:53.761632','2024-02-14 01:11:53.761632',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'oooo_0@naver.com',_binary '\0',NULL,'김영대','http://k.kakaocdn.net/dn/1G9kp/btsAot8liOn/8CWudi3uy07rvFNUkk3ER0/img_640x640.jpg','ROLE_FAN'),(47,'2024-02-14 09:18:48.376544','2024-02-14 09:18:48.376544',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'audtjd1893@naver.com',_binary '\0',NULL,'최명성','http://k.kakaocdn.net/dn/bUeoOD/btsEFMvDHqq/aKKcwK17ierqfyBySvSLkK/img_640x640.jpg','ROLE_FAN'),(48,'2024-02-14 12:54:48.187507','2024-02-14 12:55:20.496909',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'jiyeon2536@khu.ac.kr',_binary '\0','null','Jiyeon','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/jiyeon2536%40khu.ac.kr/profile/profileImage.jpg','ROLE_FAN'),(49,'2024-02-14 15:25:52.624985','2024-02-14 15:25:52.624985',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'jjm6604@nate.com',_binary '\0',NULL,'지민','http://k.kakaocdn.net/dn/1G9kp/btsAot8liOn/8CWudi3uy07rvFNUkk3ER0/img_640x640.jpg','ROLE_FAN'),(50,'2024-02-14 15:27:25.480420','2024-02-14 15:28:42.692721',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/ehddud0534%40gmail.com/certificate/certImage.jpg',1,'ehddud0534@gmail.com',_binary '\0','null','김동영','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/ehddud0534%40gmail.com/profile/profileImage.jpg','ROLE_FAN'),(53,'2024-02-15 02:16:19.217132','2024-02-15 02:16:19.217132',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'hyemin3077@daum.net',_binary '\0',NULL,'김혜민','http://k.kakaocdn.net/dn/cNlYfO/btsEQMPskNV/AA71tUQKy5TUcQcJSNJ0tK/img_640x640.jpg','ROLE_FAN'),(54,'2024-02-15 17:41:42.964724','2024-02-15 17:41:42.964724',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'sup3093@naver.com',_binary '\0',NULL,'박서현','http://k.kakaocdn.net/dn/bZE1JG/btsBC4fgwh6/EwGfpPPyCS7RxwLerzapO0/img_640x640.jpg','ROLE_FAN'),(55,'2024-02-16 12:55:29.637110','2024-02-16 12:56:14.408078',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'horizon45@naver.com',_binary '\0','null','아이유팬','http://k.kakaocdn.net/dn/1G9kp/btsAot8liOn/8CWudi3uy07rvFNUkk3ER0/img_640x640.jpg','ROLE_FAN'),(56,'2024-02-16 16:40:27.574926','2024-02-16 16:40:27.574926',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'qmak01@naver.com',_binary '\0',NULL,'박창준','http://k.kakaocdn.net/dn/hS3Ae/btsCSBPNoKk/zZqCONAn5fMkrMR2nZJYH0/img_640x640.jpg','ROLE_FAN'),(57,'2024-02-16 16:41:22.384164','2024-02-16 16:41:22.384164',NULL,'https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg',0,'tkatpgus19@naver.com',_binary '\0',NULL,'김세현','http://k.kakaocdn.net/dn/VXs7W/btsBGpoMHdy/zKk3tI8RYJOkY3huwpSTR0/img_640x640.jpg','ROLE_FAN');
/*!40000 ALTER TABLE `fan` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-19 11:46:57
