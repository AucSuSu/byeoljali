-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: my-mysql.cdokwwuykz7h.ap-northeast-2.rds.amazonaws.com    Database: byeoljali
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `artist`
--

DROP TABLE IF EXISTS `artist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artist` (
  `artist_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime(6) DEFAULT NULL,
  `last_modified_date` datetime(6) DEFAULT NULL,
  `artist_image_url` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `roles` varchar(255) DEFAULT NULL,
  `debut_date` date DEFAULT NULL,
  `fandom_name` varchar(255) DEFAULT NULL,
  `logo_image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`artist_id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist`
--

LOCK TABLES `artist` WRITE;
/*!40000 ALTER TABLE `artist` DISABLE KEYS */;
INSERT INTO `artist` VALUES (2,'2024-01-31 12:20:23.678520','2024-02-13 11:15:38.150533','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/nctdream/nctdream.jpg','SM','nctdream@gmail.com','NCT DREAM','$2a$10$M5A.VCH.rCkDTxIzAwBjc.R4/dG2qQ0pkcLfbWOZJv2DI/EXwnHWW','ROLE_ARTIST','2016-08-25','엔시티즌','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/NCT%20DREAM/logo/nctdreamlogo.svg'),(3,'2024-02-02 14:40:56.983970','2024-02-13 10:10:57.734811','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/KissOfLife/%ED%82%A4%EC%8A%A4%EC%98%A4%EB%B8%8C%EB%9D%BC%EC%9D%B4%ED%94%84%EB%8B%A8%EC%B2%B4.jpg','S2','kiss@gmail.com','KISS OF LIFE','$2a$10$ByotGPnWTmyr9PY/vO5CQ.p40tSSY8FS1PoYMkW/HSUFA147cta.6','ROLE_ARTIST','2023-07-05','키씨','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/KISS%20OF%20LIFE/logo/kissoflife.jpg'),(4,'2024-02-02 14:44:06.467194','2024-02-13 10:11:21.023861','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/BlackPink/blackpink.jpg','YG','blackpink@gmail.com','BLACK PINK','$2a$10$AW4Ph7NVyGmsl1Ek/VbXyuRiDRDW7XeijnQollSJlmzwmbpm5iCa.','ROLE_ARTIST','2016-08-08','블링크','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/BLACK%20PINK/logo/black%20pink.png'),(5,'2024-02-02 15:03:40.662985','2024-02-13 00:59:11.637929','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/IVE/%EC%95%84%EC%9D%B4%EB%B8%8C%20%EB%8B%A8%EC%B2%B4%20%EC%82%AC%EC%A7%84.jpg','STARSHIP','ive@gmail.com','IVE','$2a$10$Rgj/MbuC2lmoZucQ1.P0v.kofZfkWind5gj9rW.bqDkxDV3D0fZpu','ROLE_ARTIST','2021-12-01','다이브','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/IVE/logo/%EC%95%84%EC%9D%B4%EB%B8%8C%20%EB%A1%9C%EA%B3%A0.jpg'),(6,'2024-02-02 15:10:23.352259','2024-02-13 10:12:05.061835','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/SuperM/%EC%8A%88%ED%8D%BC%EC%97%A0.jpg','SM','superm@gmail.com','SuperM','$2a$10$LiaMLiOhZtBGx8AAB8gXU.hHwo3Y4O9oB4QYSUE0XhPDcZcEwimsK','ROLE_ARTIST','2019-10-04','SuperM SUPPORTERS','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/SuperM/logo/superM.jpg'),(89,'2024-02-06 17:25:00.383754','2024-02-13 00:57:35.090153','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/lesserafim/%EB%A5%B4%EC%84%B8.jpg','HYBE','lesserafim@gmail.com','LE SSERAFIM','$2a$10$y5uPPXVp1tFPFh7nj42ROO6a.cV8JvNLf/3uYb9FBvvN3uUbA42Ti','ROLE_ARTIST','2022-05-02','FEARNOT(피어나)','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/LE%20SSERAFIM/logo/%EB%A5%B4%EC%84%B8%EB%9D%BC%ED%95%8C%20%EB%A1%9C%EA%B3%A0.jpg'),(106,'2024-02-07 10:03:49.975134','2024-02-13 10:12:35.229523','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/RIIZE/%EB%9D%BC%EC%9D%B4%EC%A6%88.webp','SM','riize@gmail.com','RIIZE','$2a$10$dHGMcXsyQPOJsH4bZhRQTuJHy3VMQyWJi6v2o06rwjS0dDogo.FqK','ROLE_ARTIST','2023-09-04','브리즈','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/RIIZE/logo/rize.png'),(107,'2024-02-07 14:28:25.516423','2024-02-13 10:12:54.329896','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/ITZY/itzy.webp','JYP','itzy@gmail.com','ITZY','$2a$10$f7VmjpgPviraWFnt1ril5eWf/PG70GXSDY//0CbP1W3rMdaUsE./S','ROLE_ARTIST','2019-02-12','믿지','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/ITZY/logo/itzy.png'),(108,'2024-02-07 14:29:00.007136','2024-02-13 10:10:21.890946','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/NMIXX/NMIXX.webp','JYP','nmixx@gmail.com','NMIXX','$2a$10$u25eAf4HJXOkdRoRGeMbGuU4FMOX.r3trNnuKPV7tPuui6Nxnnktm','ROLE_ARTIST','2022-02-22','앤써','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/NMIXX/logo/NMIXX.png'),(109,'2024-02-07 14:29:58.656429','2024-02-13 10:13:21.372791','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/NewJeans/%EB%89%B4%EC%A7%84%EC%8A%A4.jpg','HYBE','newjeans@gmail.com','NEW JEANS','$2a$10$R1msXz6rAr92zxtoqkZpAei44FHTPrXV5Sq8oj5cEp9.QOG3RO91S','ROLE_ARTIST','2022-07-22','버니즈','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/NEW%20JEANS/logo/newjeans.png'),(110,'2024-02-07 14:30:29.927745','2024-02-13 10:13:45.904216','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/STAYC/%EC%8A%A4%ED%85%8C%EC%9D%B4%EC%8B%9C.jpeg','HIGH-UP','stayc@gmail.com','STAYC','$2a$10$8IkpA1.xffMOjXKaVTkgr.mPeqvm7KrbAV/g7iOuM6I4.ahnw9HwW','ROLE_ARTIST','2020-11-12','스윗','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/STAYC/logo/stayc.png'),(111,'2024-02-07 14:32:24.828869','2024-02-13 10:14:10.262189','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/no-profile.jpg','HYBE','seventeen@gmail.com','SEVENTEEN','$2a$10$grcka4M9PMKcpHeg3YuNRe22dAHs1kpz8FHa6/rYoOfYG17HmFTdC','ROLE_ARTIST','2015-05-26','캐럿','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/SEVENTEEN/logo/seventeen.png'),(112,'2024-02-07 14:33:44.948837','2024-02-13 13:47:28.721873','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/%28G%29I-DLE/%EC%95%84%EC%9D%B4%EB%93%A4.webp','CUBE','idle@gmail.com','(G)I-DLE','$2a$10$IuOwizcRwx8pm9S0UJ5lG.PzndWtiOvKfRNKuSnPgrhBtOci0DilK','ROLE_ARTIST','2018-05-02','네버랜드','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/%28G%29I-DLE/logo/idle.png'),(113,'2024-02-08 14:15:38.231222','2024-02-13 10:14:47.063825','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/nct127/nct127.webp','SM','nct127@gmail.com','NCT 127','$2a$10$GVAh4uHHlspFUt7ojmaA2uvR15W0LlCK43KqeY4s3k2q/ZqVGylM2','ROLE_ARTIST','2016-07-07','엔시티즌','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/NCT%20127/logo/nct127.png'),(114,'2024-02-09 13:05:58.075591','2024-02-13 00:55:27.048200','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/FROMIS_9/fromis_9.webp','PLEDIS','fromise9@gmail.com','FROMIS_9','$2a$10$eJ1.mo5ifMg66VzCYlS1rObkHZ.LfP/x5Mg.8AWz4PTnMJSruqfsq','ROLE_ARTIST','2018-01-24','플로버','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/FROMIS_9/logo/fromis_9_logo.jpg'),(115,'2024-02-10 12:38:25.775070','2024-02-13 10:15:24.599099','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/BTS/bts.png','HYBE','bts@gmail.com','BTS','$2a$10$Onfq0.ssyOAdKYO.msyNeuMzp6l1TmAYKA7ky06Hmkp7kbVsqeyZa','ROLE_ARTIST','2013-06-13','ARMY','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/artist/BTS/logo/bts.png');
/*!40000 ALTER TABLE `artist` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-19 11:46:58
