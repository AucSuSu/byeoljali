-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: my-mysql.cdokwwuykz7h.ap-northeast-2.rds.amazonaws.com    Database: byeoljali
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `photo`
--

DROP TABLE IF EXISTS `photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `photo` (
  `photo_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime(6) DEFAULT NULL,
  `last_modified_date` datetime(6) DEFAULT NULL,
  `pay` varchar(255) DEFAULT NULL,
  `photo_url` varchar(255) DEFAULT NULL,
  `artistfansign_id` bigint DEFAULT NULL,
  `fan_id` bigint DEFAULT NULL,
  `memberfansign_id` bigint DEFAULT NULL,
  PRIMARY KEY (`photo_id`),
  KEY `FKjhw99r6wp0kv9ub9uvvsir4hh` (`artistfansign_id`),
  KEY `FK8rvgechfbyeg6ow91d3mdr2q4` (`fan_id`),
  KEY `FK1ge6q6ffnq8irlbuug11p65m1` (`memberfansign_id`),
  CONSTRAINT `FK1ge6q6ffnq8irlbuug11p65m1` FOREIGN KEY (`memberfansign_id`) REFERENCES `member_fansign` (`memberfansign_id`),
  CONSTRAINT `FK8rvgechfbyeg6ow91d3mdr2q4` FOREIGN KEY (`fan_id`) REFERENCES `fan` (`fan_id`),
  CONSTRAINT `FKjhw99r6wp0kv9ub9uvvsir4hh` FOREIGN KEY (`artistfansign_id`) REFERENCES `artist_fansign` (`artistfansign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo`
--

LOCK TABLES `photo` WRITE;
/*!40000 ALTER TABLE `photo` DISABLE KEYS */;
INSERT INTO `photo` VALUES (46,'2024-02-15 10:02:59.316150','2024-02-15 10:03:50.715860','Y','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/allback123%40gmail.com/life4cut/27/life4cut.jpg',12,1,27),(47,'2024-02-15 14:11:47.503120','2024-02-15 14:11:47.503120','N','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/allback123%40gmail.com/life4cut/27/life4cut.jpg',12,1,27),(48,'2024-02-15 17:03:30.030193','2024-02-15 17:09:41.258017','Y','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/ice_98%40naver.com/life4cut/27/life4cut.jpg',12,27,27),(50,'2024-02-15 19:46:31.840237','2024-02-15 19:46:31.840237','N','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/allback123%40gmail.com/life4cut/27/life4cut.jpg',12,1,27),(51,'2024-02-15 20:54:46.888085','2024-02-15 20:54:46.888085','N','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/allback123%40gmail.com/life4cut/27/life4cut.jpg',12,1,27),(52,'2024-02-15 21:17:06.187424','2024-02-15 21:17:06.187424','N','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/allback123%40gmail.com/life4cut/27/life4cut.jpg',12,1,27),(53,'2024-02-16 01:34:41.945374','2024-02-16 01:35:17.796974','Y','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/dalsu_k%40naver.com/life4cut/27/life4cut.jpg',12,6,27),(54,'2024-02-16 09:32:45.009092','2024-02-16 09:32:45.009092','N','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/allice1010%40naver.com/life4cut/423/life4cut.jpg',188,5,423),(55,'2024-02-16 12:04:31.269853','2024-02-16 12:04:31.269853','N','https://testbyeoljari.s3.ap-northeast-2.amazonaws.com/fan/dalsu_k%40naver.com/life4cut/422/life4cut.jpg',187,6,422);
/*!40000 ALTER TABLE `photo` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-19 11:46:58
